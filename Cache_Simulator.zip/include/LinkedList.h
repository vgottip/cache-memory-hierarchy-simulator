#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <stdio.h>
#include <stdint.h>


typedef struct node{
    struct _cacheDS* cacheLevelPtr;       // points to the Data
    struct node* nextPtr;   // points to the next node (Linked List)
}TLinkedListNode; 

uint32_t LLCountNodes(TLinkedListNode *headPtr);

void LLAppend(TLinkedListNode *headPtr, TLinkedListNode* newNodePtr);

#endif